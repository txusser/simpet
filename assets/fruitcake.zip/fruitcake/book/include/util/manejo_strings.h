#ifndef 	MANEJO_STRINGS__H
#define MANEJO_STRINGS__H

void cuenta_tokens_ascii(const char *nombre_fichero,int *ntokens);
void dim_matriz_ascii(const char *nombre_fichero,int *nfil, int *ncol);
float lee_elemento_matriz_ascii(const char *nombre_fichero,int nfil_sel, int ncol_sel);
void separa_tokens_ascii(const char *nombre_fichero,char **palabras);
void cuenta_tokens(char *buf,int *ntokens, const char *separador);
void separa_tokens(char *buf,char **palabras,const char *separador);

#endif //__MANEJO_STRINGS_H
