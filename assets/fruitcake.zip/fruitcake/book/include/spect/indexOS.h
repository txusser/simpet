#ifndef __INDEXOS__H
#define __INDEXOS__H

void calcul_indexs(int *indexs,int OS,int NangdOS);
void ordenar_proj_pmp3dxOS(float *le,float *le2,int Nang,int Nbt,int Nbp,int OS);
void reordenar_projxOS(float *le,float *le2,int Nang,int Nbt,int Nbp,int OS);
void generar_nom_mpes(char *mpes_nou,char *mpes_original,int k,int OS);
void calcul_dif(int *dif,int OS);

#endif 
