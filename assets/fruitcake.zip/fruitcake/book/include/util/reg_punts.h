#ifndef REG_PUNTS__H
#define REG_PUNTS__H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <util/inpout.h>

/* ====================================== GIR I DESPLACAMENT ================ */
void girdesp3d(struct imagen *ima,double xd,double yd,double zd,double xc,double yc,double zc,double fi,double theta,double tzeta,struct imagen *ima2);

/* ====================================== GIR I DESPLACAMENT INVERS================ */
void girdesp3d_invers(struct imagen *ima,double xd,double yd,double zd,double xc,double yc,double zc,double fi,double theta,double tzeta,struct imagen *ima2);

/*===============================================================================================*/
void girdesp3d_2(struct imagen *ima,float xd,float yd,float zd,float xc,float yc,float zc,float *prom_a,struct imagen *ima2);

#endif /*REG_PUNTS__H*/
