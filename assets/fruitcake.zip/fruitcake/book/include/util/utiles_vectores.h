#ifndef __UTILES_VECTORES_H
#define __UTILES_VECTORES_H

struct coord3d
{
  float x;
  float y;  
  float z;
};

void producto_vectorial(float u1,float u2,float u3,float v1,float v2,float v3, float *R1,float *R2,float *R3);
float modulo_vector(float v1,float v2,float v3);
void producto_vectorial_ss(struct coord3d u,struct coord3d v, struct coord3d *r);
float modulo_vector_ss(struct coord3d v);
#endif /*__UTILES_VECTORES_H */




