#ifndef CENTRODM__H
#define CENTRODM__H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <util/inpout.h>
#include <util/nrutil.h>

void cdms(struct imagen *ima,float *x,float *y,float *z);

#endif /*CENTRODM__H*/
