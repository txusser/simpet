/* Declaracion de las variables globales	 mayo2005 */

#include <util/mp_i4.h>

int MM,PN,M,N,P;
sparse_i4 mp;
int Nvox,Nbt,Nbp,Nang;
float *q;
