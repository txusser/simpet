#ifndef __POCS3D_PET_H
#define __POCS3D_PET_H

#include <util/mp_i4.h>

extern sparse_i4 mp;
extern int Nvox,Nbt,Nbp,Nang;
extern float *q;

void pocs(char *fitxer_resultats,float *le,float *vp,char tipout[3],int NITER,float W,float nc);

void rec_pocs(float *q2,float *le,float *lc,float *vp,float W,int *index,int *masc,int nc);

void omple_mascara(int *masc,float *le,float *lc);

#endif //__POCS3D_PET_H






