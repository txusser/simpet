#ifndef __ENC_CENTROS_H
#define __ENC_CENTROS_H

// double tp,x1cm,y1cm,sgx1;
// double pi;
// 
// double *sf;
// double *t;
//int n = 0,ndim = 3,ndim2,npar=13, z=0;

// Los parametros de entrada son ntt, *v, rad_px, fov. Que son respectivamente:
// tama�o de la imagen. Vector q contiene la imagen, radio maximo en pixeles de los
// ptos de la imagen. Factor de reduccion de la imagen (evita aros y ruidos) (un 1
// implica coger toda la pantalla).

// Los parametros de salida son: puntos= n� de ptos encontrados. *vectx y *vecty= Los
// vectores que contienen las componentes x e y respectivamente, de los ptos encontrados.
// minimo= Valor m�nimo en cuentas encontrado. amplitud= vector con la amplitud max de
// cada uno de los ptos enontrados.

void encuentra(int ntt, int *puntos, int *vectx, int *vecty, float *v, float *minimo, float *ampli, int rad_px, int fov);


#endif /*__ENC_CENTROS_H */
