#ifndef CPIMA3D__H
#define CPIMA3D__H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <util/inpout.h>
#include <util/nrutil.h>













#endif /*CPIMA3D__H*/
