
/********************************************************************************
Librer�a que contiene funciones espec�ficas para el c�lculo de 
los coeficientes de Klein-Nishina
paguiar Noviembre2004
***********************************************************************************/


/*RADIO_PHOTON_ENERGY*/
/*Calcula la relacion entre la energia del foton antes/despues de la colision
E energ�a en eV del fot�n antes de la colisi�n
theta_rad �ngulo de dispersi�n en radianes*/
double ratio_photon_energy(double E,double theta_rad);
