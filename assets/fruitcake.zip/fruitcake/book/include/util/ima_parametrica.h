#ifndef __IMA_PARAMETRICA__H
#define __IMA_PARAMETRICA__H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <util/inpout.h>

int diferen(struct imagen *im1,struct imagen *im2,struct imagen *it,int tipo);
int mask_imafun(struct imagen *dif,struct imagen *bas,struct imagen *ict);
int separa_pos_neg(struct imagen *it,struct imagen *it1,struct imagen *it2);

/*int diferen_con_mascara(struct imagen *im1,struct imagen *im2,double *masc,struct imagen *it, int tipo);*/
#endif /*__IMA_PARAMETRICA__H*/
